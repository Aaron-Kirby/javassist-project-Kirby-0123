package ex04;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtConstructor;
import javassist.CtMethod;
import javassist.NotFoundException;
import target.Common;

public class ToClass {
	private static final String PKG_NAME = "target" + ".";

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<String> list = new ArrayList<String>();
		String name = "";
		do {
			System.out.println("Please enter one class name to be modified (e.g. CommonServiceA or CommonComponentB):");
			String input = sc.nextLine();
			String[] arr = input.split(",");
			for (String i : arr) {
				list.add(i.trim());
			}

			if (list.size() != 1) {
				System.out.println("[WRN] Invalid Input");
				for (int i = 0; i < arr.length; i++) {
					arr[i] = null;
				}
				list.clear();
			} else {
				name = list.get(0);
			}
		} while (name.compareTo("") == 0);
		String classname = PKG_NAME + name;
		System.out.println("=================================");

		try {
			ClassPool pool = ClassPool.getDefault();
			CtClass cc = pool.get(classname);
			CtConstructor declaredConstructor = cc.getDeclaredConstructor(new CtClass[0]);
			
			String printBlock = "{ " + "System.out.println(\"id: \" + id);" + "System.out.println(\"year: \" + year);"
					+ " }";
			declaredConstructor.insertAfter(printBlock);
			Class<?> c = cc.toClass();
			Common ci = (Common) c.newInstance();
		} catch (NotFoundException | CannotCompileException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
	}
}